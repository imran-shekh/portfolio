from django.apps import AppConfig


class ElearningConfig(AppConfig):
    name = 'ELearning'
